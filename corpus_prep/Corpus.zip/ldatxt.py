import requests
import html2text
import re

def remove_titles(text):
    clean = re.compile('<h2.*?/h2>')
    text = re.sub(clean, '', text)
    clean = re.compile('<h3.*?/h3>')
    text = re.sub(clean, '', text)
    clean = re.compile('<a href="#bib.*?/a>')
    text = re.sub(clean, '', text)
    clean = re.compile('<h4.*?/h4>')
    return re.sub(clean, '', text)

pmcid = "7556561"
url = "https://www.ncbi.nlm.nih.gov/pmc/articles/PMC"+pmcid+"/"
response = requests.get(url)
text = response.text
span_end = max(text.find('<div id="b'), text.find('<div id="ceb'))
span_beg = max(text.find('<p id="p'), text.find('<p id="__p'))
text = text[span_beg:span_end]
text = remove_titles(text)
text = html2text.html2text(text)
list01 = text.split(".\n")
list02 = []
for l in list01:
    list02 += l.split(". ")
list01 = []
for l in list02:
    list01.append(l.replace("\n", " "))
f = open(pmcid+"_en.txt", "w", encoding='utf8')
for l in list01:
    if (l.count("/") <= 2) and (l.find("|") < 0):
        if (l != " [[![An external file that holds a picture, illustration, etc") and (l != ""):
            if (l[0] == " "):
                if (l.find("1\\")>=0): break
                f.write(l[1:]+"\n")
            else:
                f.write(l+"\n")
    f.flush()
f.close()
